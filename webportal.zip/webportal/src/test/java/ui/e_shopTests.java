package ui;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class e_shopTests {
	protected WebDriver driver;

	public void AbstractClass(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public static void resultsToFile(String text, String fileName) throws IOException {
		FileWriter fw = new FileWriter(fileName, true);// open file to write info
		BufferedWriter bw = new BufferedWriter(fw);// teksto rasymui
		PrintWriter pw = new PrintWriter(bw);// kaskart irasineti atskiroje eiluteje.
		pw.println(text);

		pw.close();// uzdarome irasinejimo faila.
	}

	// Lokatoriai
	private By inputSearch = By.xpath("//input[@id='search_query_top']");
	private By buttonSearch = By.xpath("//button[@name='submit_search']");
	private By titleBlouse = By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']");
	private By printedChiffonDress = By.xpath("//a[@class='product-name'][@title='Printed Chiffon Dress']");
	private By buttonAddToChart = By.xpath("//span[normalize-space()='Add to cart']");
	private By proceedToCheckout = By.xpath("//span[normalize-space()='Proceed to checkout']");
	private By proceedToCheckoutDoublecheck = By.xpath("//a[@class='button btn btn-default standard-checkout button-medium']//span[contains(text(),'Proceed to checkout')]");
    private By inputEmail = By.xpath("//input[@id='email']");
    private By inputPassword = By.xpath("//input[@id='passwd']");
    private By buttonSignIn = By.xpath("//span[normalize-space()='Sign in']");
    private By buttonSignOut = By.xpath("//a[@title='Log me out']");
    private By proceedToCheckoutFromAddress = By.xpath("//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]");
    private By checkboxTermsAgreement = By.xpath("//input[@id='cgv']");
    private By proceedToCheckoutFromShipping = By.xpath("//button[@name='processCarrier']//span[contains(text(),'Proceed to checkout')]");
    private By buttonPayByCheck = By.xpath("//a[@title='Pay by check.']");

 
    
	@BeforeTest
	public void setUp() {
		ChromeOptions opt1 = new ChromeOptions();
		driver = new ChromeDriver(opt1);
		opt1.addArguments("headless");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}

	@Test(priority = 1, description = "Test Nr.1:launch browser and navigate to the website")
	public void launchBrowserNawigateToWebsite() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.1:'launch browser and navigate to the website'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			if (driver.findElements(By.xpath("//img[@alt='My Store']")).size() != 0) {
				System.out.println("OK. Naudotojas nunavigavo � website.");
				resultsToFile("OK. Naudotojas nunavigavo � website.", "src/test/resources/results.txt");
			} else {
				System.out.println("Error! Nepavyksta nunaviguoti � website.");
				resultsToFile("Error! Nepavyksta nunaviguoti � website.","src/test/resources/results.txt");
			}
		} catch (Exception e) {
			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error! Nepavyksta atlikti testo Nr.1.");
			resultsToFile("Error! Nepavyksta atlikti testo Nr.1.", "src/test/resources/results.txt");
		}
	}

	@Test(priority = 2, description = "Test Nr.2:enter product name into search field and click search")
	public void searchForProduct() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.2:'launch browser and navigate to the website'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			driver.findElement(inputSearch).sendKeys("dress");
			driver.findElement(buttonSearch).click();
			if (driver.findElements(By.xpath("//img[@alt='My Store']")).size() != 0) {
				System.out.println("OK. Search for 'dress' atliktas.");
				resultsToFile("OK. Search for 'dress' atliktas.", "src/test/resources/results.txt");
			} else {
				System.out.println("Error! Search for 'dress' neatliktas.");
				resultsToFile("Error! Search for 'dress' neatliktas.","src/test/resources/results.txt");
			}
		} catch (Exception e) {

			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error! Nepavyksta atlikti search.");
			resultsToFile("Error! Nepavyksta atlikti search.", "src/test/resources/results.txt");
		}
	}

	@Test(priority = 3, description = "check that correct product is visible after search")
	public void checkCorrectProductIsVisible() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.3:'check that correct product is visible after search'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			driver.findElement(inputSearch).sendKeys("dress");
			driver.findElement(buttonSearch).click();
			driver.findElement(titleBlouse).getAttribute("Blouse");
			if (driver.findElements(By.xpath("//a[@title='Blouse'][normalize-space()='Blouse']")).size() != 0) {
				System.out.println("Error! Search pagal 'dress' vyksta netinkamai.");
				resultsToFile("Error! Search pagal 'dress' vyksta netinkamai.", "src/test/resources/results.txt");
			} else {
				System.out.println("OK. Search pagal 'dress' vyksta tinkamai");
				resultsToFile("OK. Search pagal 'dress' vyksta tinkamai", "src/test/resources/results.txt");
			}
		} catch (Exception e) {
			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error. Nepavyksta patikrinti ar tinkamai atliktas search pagal 'dress'");
			resultsToFile("Error. Nepavyksta patikrinti ar tinkamai atliktas search pagal 'dress'","src/test/resources/results.txt");
		}
	}

	
	@Test(priority = 4, description = "click add product to cart and check that product is visible in a shopping cart")
	public void addProductToChartCheckVisibleInTheChart() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.4:'click add product to cart and check that product is visible in a shopping cart'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			driver.findElement(inputSearch).sendKeys("dress");
			driver.findElement(buttonSearch).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.findElement(printedChiffonDress).click();
			driver.findElement(buttonAddToChart).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			if (driver.findElements(By.xpath("//h2[normalize-space()='Product successfully added to your shopping cart']")).size() != 0) {
				System.out.println("OK. Produkt� pavyko �d�ti � krep�el�, �inut� 'Product successfully added to your shopping cart' atvaizduota");
				resultsToFile("OK. Produkt� pavyko �d�ti � krep�el�, �inut� 'Product successfully added to your shopping cart' atvaizduota", "src/test/resources/results.txt");
			} else {
				System.out.println("Error! Produkto nepavyko �d�ti � krep�el�");
				resultsToFile("Error! Produkto nepavyko �d�ti � krep�el�", "src/test/resources/results.txt");
			}
		} catch (Exception e) {
			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error! Nepavyksta �d�ti prek�s � krep�el� ir/ar patikrinti ar prek� krep�elyje");
			resultsToFile("Error! Nepavyksta �d�ti prek�s � krep�el� ir/ar patikrinti ar prek� krep�elyje","src/test/resources/results.txt");
		}
	}
	
	@Test(priority = 5, description = "continue to checkout and fill required information")
	public void checkoutAndFillReqInfo() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.5:'continue to checkout and fill required information'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			driver.findElement(inputSearch).sendKeys("dress");
			driver.findElement(buttonSearch).click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.findElement(printedChiffonDress).click();
			driver.findElement(buttonAddToChart).click();
			driver.findElement(proceedToCheckout).click();
			driver.findElement(proceedToCheckoutDoublecheck).click();
			driver.findElement(inputEmail).sendKeys("jolita.budrikiene@gmail.com");
			driver.findElement(inputPassword).sendKeys("pasword123");
			driver.findElement(buttonSignIn).click();
			if (driver.findElements(By.xpath("//h3[normalize-space()='Your delivery address']")).size() != 0) {
				System.out.println("OK. Naudotojas nunavigavo � SignIn lang�, �ved� reikalaujamus duomenis ir prisijung�");
				resultsToFile("OK. Naudotojas nunavigavo � SignIn lang�, �ved� reikalaujamus duomenis ir prisijung�.", "src/test/resources/results.txt");
			} else {
				System.out.println("Error! Naudotojas neprisijung�");
				resultsToFile("Error! Naudotojas neprisijung�","src/test/resources/results.txt");
				Thread.sleep(5000);
			}
			driver.findElement(buttonSignOut).click();
		} catch (Exception e) {
			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error! Nepavyksta atlikti checkout ir fill in required information");
			resultsToFile("Nepavyksta atlikti checkout ir fill in required information","src/test/resources/results.txt");
		}
	}

	@Test(priority = 6, description = "continue to payments page and verify payment options")
	public void verifyPaymentNew() throws InterruptedException, IOException {
		try {
			resultsToFile("***Webportal/Test Nr.6:'continue to payments page and verify payment options'***","src/test/resources/results.txt");
			driver.get("http://automationpractice.com/index.php");
			driver.findElement(inputSearch).sendKeys("blouse");
			driver.findElement(buttonSearch).click();
			driver.findElement(titleBlouse).click();
			driver.findElement(buttonAddToChart).click();
			driver.findElement(proceedToCheckout).click();
			driver.findElement(proceedToCheckoutDoublecheck).click();
			driver.findElement(inputEmail).sendKeys("jolita.budrikiene@gmail.com");
			driver.findElement(inputPassword).sendKeys("pasword123");
			driver.findElement(buttonSignIn).click();
			driver.findElement(proceedToCheckoutFromAddress).click();
			driver.findElement(checkboxTermsAgreement).click();
			driver.findElement(proceedToCheckoutFromShipping).click();
			driver.findElement(buttonPayByCheck).click();
			if (driver.findElements(By.xpath("//h3[@class='page-subheading']")).size() != 0) {
				System.out.println("OK. Naudotojas nunavigavo � payments lang� ir pasirinko mok�jimo b�d�");
				resultsToFile("OK. Naudotojas nunavigavo � payments lang� ir pasirinko mok�jimo b�d�", "src/test/resources/results.txt");
			} else {
				System.out.println("Error! Naudotojui nepavyko patekti � payments lang� ir pasirinkti mok�jimo b�d�.");
				resultsToFile("Error! Naudotojui nepavyko patekti � payments lang� ir pasirinkti mok�jimo b�d�.","src/test/resources/results.txt");
			}
				
		} catch (Exception e) {
			// sugaunama klaida, jei nepavyksta testas 'try' dalyje.
			System.out.println("Error! Nepavyksta atlikti verify payment options testo");
			resultsToFile("Error! Nepavyksta atlikti verify payment options testo", "src/test/resources/results.txt");
		}
	}


    @AfterTest
	public void cleanUp() {
		driver.manage().deleteAllCookies();
	}

	@AfterTest
	public void tearDown() {
		driver.close();
	}

}
